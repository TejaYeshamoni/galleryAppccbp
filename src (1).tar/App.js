import Gallery from './components/Gallery'

import './App.css'

const App = () => <Gallery />

export default App
